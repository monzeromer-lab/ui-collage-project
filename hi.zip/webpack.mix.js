const mix = require('laravel-mix');


mix.disableNotifications()
.options({processCssUrls: true})